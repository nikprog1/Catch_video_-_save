// Пример js43
import * as lib from './lib.js';

// Выполнить скрипт после загрузки документа
$(document).ready(function()
{
$('#intro').parallax("50%", 0.3); //Параллакс
lib.InitForm(); //Валидация формы
lib.InitFlipClock(); //Таймер
lib.hello(); //Приветствие
lib.Initjello();
lib.Initjello1();
lib.Initjello2();
lib.Initjello3();
lib.InitDraw(); //Диаграмма
console.log("Работает");//Тест
});


